document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('[data-confirm]').forEach(x=>x.addEventListener('click',e=>{if(!confirm(x.dataset.confirm))e.preventDefault()}));
  document.querySelectorAll('.toast').forEach(x=>setTimeout(()=>x.classList.add('toast-hide'),4200));
  document.querySelectorAll('img').forEach(img=>img.addEventListener('error',()=>{img.classList.add('img-fallback');}));
});
async function drawChart(id,url,type='line'){const el=document.getElementById(id);if(!el)return;const r=await fetch(url);if(!r.ok)return;const d=await r.json();if(!d.labels.length)return;const c=document.createElement('canvas');el.innerHTML='';el.appendChild(c);new Chart(c,{type,data:{labels:d.labels,datasets:[{label:'Revenue',data:d.values,borderWidth:3,tension:.35,fill:type==='line'}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}})}
